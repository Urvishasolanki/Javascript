







let x = 30;
let y = 20;
let z = 6;


let sum = x + y;

let remainder = sum % z;


console.log("The remainder of (" + x + " + " + y + ") / " + z + " is: " + remainder);
