let base = 8;
let height = 6;
let area = 0.5 * base * height;
console.log("The area of the triangle with base " + base + " and height " + height + " is: " + area);