


let number = 7;


let square = number * number;


console.log(square); 