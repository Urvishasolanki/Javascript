let width = 10;
let height = 5;
let area = width * height;
console.log("The area of the rectangle with width " + width + " and height " + height + " is: " + area);