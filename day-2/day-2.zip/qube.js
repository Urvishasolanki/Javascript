







let number = prompt("Please enter a number:");


number = Number(number);

let cube = number * number*number;

document.write("The cube of " + number + " is " + cube);