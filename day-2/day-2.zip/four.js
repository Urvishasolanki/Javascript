let A = 1;
let B = 2;
let C = 3;
let D = 4;
let E = 5;
let F = 6;
let G = 7;


let sum1 = A + B + C;


let sum2 = D + E + F + G;


let product = sum1 * sum2;

console.log("The product of (A + B + C) * (D + E + F + G) is " + product);