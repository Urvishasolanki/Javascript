let one = 5;
let two = 10;
let three = 15;
let four = 20;
let five = 25;


let sum = one + two + three + four + five;


console.log("The sum of the variables is: " + sum);