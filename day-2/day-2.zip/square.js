let one = 3;
let two = 4;
let three = 5;

let squareofOne = one * one;
let squareofTwo = two * two;
let squareofThree = three * three;

let sumOfSquares = squareofOne + squareofTwo + squareofThree;
document.write(squareofOne);
document.write(squareofTwo);
document.write(squareofThree);
document.write("sum is",sumOfSquares)

