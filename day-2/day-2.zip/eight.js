let number = 4;

number = number * 3;

number = number + 7;

number = number - 10;

console.log("The updated value is: " + number);