let a = 5;
let b = 10;
let c = 8;
let d = 7;


let sum = a + b + d;


let result = sum - c;

console.log("The result of (a + b + d) - c is: " + result);