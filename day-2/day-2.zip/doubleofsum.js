let one = 10;
let two = 15;
let three = 5;
let four = 8;
let five = 12;


let sum = one + two + three + four + five;

let doubledSum = sum * 2;


document.write("the sum of "+ one + " " + two +  " " + three + " " + four + " " + five +" "+ "is " + sum +"<br>");
document.write("double of sum is ="+doubledSum);
