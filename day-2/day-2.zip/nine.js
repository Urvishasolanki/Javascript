let radius = 11;
const pi=3.14;
let area = pi * radius * radius;

console.log("The area of the circle with radius " + radius + " is: " + area);