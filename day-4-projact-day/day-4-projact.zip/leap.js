// Determine if a given year is a leap year. Print true or false only.
let year=2025;
if(year % 4 == 0){
    console.log("true");
}
else
{
    console.log("false");
}
