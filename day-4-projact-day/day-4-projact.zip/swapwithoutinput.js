let a = 5;
let b = 10;


a = a + b; 
b = a - b; 
a = a - b;

console.log(a); 
console.log(b); 