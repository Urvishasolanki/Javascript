let a = 29;
let b = 6;


let remainder = a % b;

console.log(remainder); 