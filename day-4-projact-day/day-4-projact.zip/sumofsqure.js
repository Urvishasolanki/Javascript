// Compute the sum of the squares of three numbers.
// 3, 4, 5
// Sum of squares: 50
let a=3;
let b=4;
let c=5;

let sq_a=3*3;
let sq_b=4*4;
let sq_c=5*5;

let sumofsqure=sq_a+sq_b+sq_c;
console.log("sum of squre is " + sumofsqure);